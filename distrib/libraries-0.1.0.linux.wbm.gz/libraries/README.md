##Libraries API module for Webmin.

##Installation:

API module created to make use of various JS, CSS frameworks within Webmin modules easier.
